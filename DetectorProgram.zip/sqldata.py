import pandas as pd 
import os
import pyodbc 
def connect_db():
    try:
        Driver = '{ODBC Driver 17 for SQL Server}'
        Server = 'localhost'
        Database = 'amagcons'
        Pwd = 'amagcons_vm#12'
        Uid = 'sa'
        # Creating Script
        PYODBC_Connection = 'DRIVER=' + Driver + ';SERVER=' + Server +  ';DATABASE=' + Database + ';UID=' + Uid + ';PWD=' + Pwd + ";Encrypt=yes;TrustServerCertificate=yes"  
        cnxn = pyodbc.connect(PYODBC_Connection)
        return "SUCCESS", cnxn
    except:
        return "FAILURE", None


def ret_pandas(sql):
    try:
        cnxn, sts = connect_db()           
        if sts =="SUCCESS":
            df = pd.read_sql(sql, cnxn)                          
            cnxn.commit()
            cnxn.close()
        else:
            df = None      
        return df, sts
    except Exception as ex:                    
        return None, "FAILURE:  " + str(ex) 

def run_sql(sql):
    try:
        cnxn, sts = connect_db()
        if (cnxn=="SUCCESS"):
            cursor = cnxn.cursor()            
            cursor.execute(sql)
            cnxn.commit()
            cnxn.close()
            sts="SUCCESS"        
        return sts 
    except Exception as ex:            
        sts = "FAILURE:  " + str(ex)        
        return sts                  